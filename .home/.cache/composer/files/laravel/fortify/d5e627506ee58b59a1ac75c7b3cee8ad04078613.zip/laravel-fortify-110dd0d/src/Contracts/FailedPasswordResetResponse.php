<?php

namespace Laravel\Fortify\Contracts;

use Illuminate\Contracts\Support\Responsable;

interface FailedPasswordResetResponse extends Responsable
{
    //
}
