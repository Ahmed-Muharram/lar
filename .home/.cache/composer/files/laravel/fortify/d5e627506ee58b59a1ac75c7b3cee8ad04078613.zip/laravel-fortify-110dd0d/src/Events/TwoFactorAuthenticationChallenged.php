<?php

namespace Laravel\Fortify\Events;

class TwoFactorAuthenticationChallenged extends TwoFactorAuthenticationEvent
{
    //
}
