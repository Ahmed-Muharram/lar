<?php

namespace Laravel\Fortify\Events;

class TwoFactorAuthenticationConfirmed extends TwoFactorAuthenticationEvent
{
    //
}
