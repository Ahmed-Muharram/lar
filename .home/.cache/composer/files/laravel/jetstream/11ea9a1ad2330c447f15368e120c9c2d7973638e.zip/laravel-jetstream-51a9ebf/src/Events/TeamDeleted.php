<?php

namespace Laravel\Jetstream\Events;

class TeamDeleted extends TeamEvent
{
    //
}
