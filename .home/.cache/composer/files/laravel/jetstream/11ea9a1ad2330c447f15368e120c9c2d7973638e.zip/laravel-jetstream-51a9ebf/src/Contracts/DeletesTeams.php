<?php

namespace Laravel\Jetstream\Contracts;

/**
 * @method void delete(\Illuminate\Database\Eloquent\Model $team)
 */
interface DeletesTeams
{
    //
}
