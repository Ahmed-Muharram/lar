<?php

namespace Laravel\Jetstream\Contracts;

/**
 * @method void delete(\Illuminate\Foundation\Auth\User $user)
 */
interface DeletesUsers
{
    //
}
